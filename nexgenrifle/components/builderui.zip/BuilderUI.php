<?php namespace Marty\NexgenRifle\Components;

use Cms\Classes\ComponentBase;

/**
 * BuilderUI Component
 *
 * @link https://docs.octobercms.com/3.x/extend/cms-components.html
 */
class BuilderUI extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name' => 'Builder U I Component',
            'description' => 'No description provided yet...'
        ];
    }

    /**
     * @link https://docs.octobercms.com/3.x/element/inspector-types.html
     */
    public function defineProperties()
    {
        return [];
    }
    
    /**
     * Executed when the component is run on a page or layout.
     */
    public function onRun()
    {
        // Add October CMS framework JavaScript
        $this->addJs('/modules/system/assets/js/framework.js');

        // Add JavaScript files in the appropriate dependency order
        $this->addJs('/plugins/marty/nexgenrifle/components/builderui/assets/js/price-calculator.js');
        $this->addJs('/plugins/marty/nexgenrifle/components/builderui/assets/js/build-persistence.js'); // Component version
        $this->addJs('/plugins/marty/nexgenrifle/components/builderui/assets/js/product-manager.js');    // Component version
        $this->addJs('/plugins/marty/nexgenrifle/components/builderui/assets/js/group-manager.js');
        $this->addJs('/plugins/marty/nexgenrifle/components/builderui/assets/js/builder-ui.js');
        $this->addJs('/plugins/marty/nexgenrifle/components/builderui/assets/js/builder-core.js');
    }
    
    /**
     * Method for handling the onShowGroupDetails AJAX request.
     * This method loads a specific component partial based on the 'groupType' parameter
     * sent via POST. The rendered partial content is returned to update an HTML
     * element on the page, typically identified by a CSS selector like '#groupDetailsTarget'.
     */
    public function onShowGroupDetails()
    {
        $groupType = post('groupType'); // Expected values: 'lower-receiver', 'upper-receiver', 'tools', etc.

        if (!$groupType) {
            // Return an error message if groupType is not provided
            return ['#groupDetailsTarget' => '<p class="text-danger">Error: Group type not specified.</p>'];
        }

        // Construct the partial alias from the groupType.
        // Example: 'lower-receiver' becomes '@lower-receiver-group'.
        // The '@' symbol indicates a partial within this component's directory.
        // Handles variations like 'LOWER_RECEIVER' or 'lower-receiver'.
        $partialAlias = '@' . str_replace('_', '-', strtolower($groupType)) . '-group';

        // Define a list of allowed partials to prevent arbitrary file loading and ensure validity.
        // These correspond to .htm files in the plugins/marty/nexgenrifle/components/builderui/ directory.
        $allowedPartials = [
            '@lower-receiver-group',
            '@upper-receiver-group',
            '@tools-group'
            // Add other valid group partial aliases here if they exist (e.g., '@another-custom-group')
        ];

        if (in_array($partialAlias, $allowedPartials)) {
            try {
                // Render the specified partial.
                // The key '#groupDetailsTarget' is the CSS selector for the HTML element
                // that will be updated with the partial's content.
                // Ensure this selector matches an element in your `default.htm` or page layout.
                return ['#groupDetailsTarget' => $this->renderPartial($partialAlias)];
            } catch (\Exception $e) {
                // Optional: Log the error for debugging.
                // Requires: use Winter\Storm\Support\Facades\Log; at the top of the file.
                // Log::error('Partial rendering failed for ' . $partialAlias . ': ' . $e->getMessage());
                
                // Return an error message to the frontend.
                // Using e() helper to escape $groupType for security.
                return ['#groupDetailsTarget' => '<p class="text-danger">Error: Could not load details for ' . e($groupType) . '. The partial might be missing or contain errors.</p>'];
            }
        } else {
            // Handle unknown or disallowed groupType.
            // Using e() helper to escape $groupType for security.
            return ['#groupDetailsTarget' => '<p class="text-warning">Warning: The requested group type (' . e($groupType) . ') is not recognized.</p>'];
        }
    }
    
    /**
     * Method for handling the onSaveBuild AJAX request
     */
    public function onSaveBuild()
    {
        $buildData = post('buildData');
        // Logic to save the build data
        // This is a placeholder for the existing or future implementation
    }
    
    /**
     * Method for handling the onLoadBuild AJAX request
     */
    public function onLoadBuild()
    {
        // Logic to load the saved build data
        // This is a placeholder for the existing or future implementation
        return ['buildData' => null]; // Replace with actual saved build data
    }
}
